I have attemped the bonus part of the assignment.

How to compile amd run the program:
1) download the folder "code" on the desktop.
2) open this directory in the command prompt.
3) complie the files using the command "javac *.java"
4) run the file using the command "java Assign5 inputA5 output1" for linear probing
5) run the file using the command "java Assign5 -q inputA5 output2" for quadratic probing
public class Assign5
{
    public static void main(String[] args)
    {
        if(args.length > 3 || args.length < 2)
        {
            System.out.println("Invalid number of arguments!");
            System.exit(1);
        }
        if(args[0].equals("-q"))
        {
            Utility my_test = new Utility(args[0],args[1],args[2]);
            my_test.readData();
            my_test.searchData();
        }
        else
        {
            Utility my_test = new Utility("nullFlag",args[0],args[1]);
            my_test.readData();
            my_test.searchData();
        }
    }
}
public class HashTable
{
    private double readings;
    private int mChain;
    private String probFlag;
    private double numberOfRecords;
    private int cap;
    private String[] table;

    public HashTable(int sizeOfTable, String flag)
    {
        this.numberOfRecords = sizeOfTable;
        this.cap = nextPrime((int)Math.round(sizeOfTable*1.42));
        this.table = new String[this.cap];
        this.readings = 0;
        this.mChain = 0;
        this.probFlag = flag;
    }

    public int hash(String key)
    {
        int address = 0;
        for(int j=0; j<key.length();j++)
        {
            address = (address << 3) | (address >>> 27);
            address = address + (int)key.charAt(j); 
        }
        return Math.abs((address*31)%this.cap);
    }

    private int findPosLinearProbing(String key)
    {
        int i = hash(key);
        int chainCounter = 0;

        for(int j = 0; j<this.table.length;j++)
        {
            if(this.table[i] == null || this.table[i].equals(key))
            {
                this.readings++;
                chainCounter++;
                if(chainCounter > this.mChain)
                {
                    this.mChain = chainCounter;
                }
                return i;
            }
            else
            {
                i = (i+1)%this.cap;
                this.readings++;
                chainCounter++;
            }
        }
        return i;
    }

    private int findPosQuadraticProbing(String key)
    {
        int i = hash(key);
        int chainCounter = 0;
        for(int j = 1; j<this.table.length;j++)
        {
            if(this.table[i] == null || this.table[i].equals(key))
            {
                this.readings++;
                chainCounter++;
                if(chainCounter > this.mChain)
                {
                    this.mChain = chainCounter;
                }
                return i;
            }
            else
            {
                i = (i+ j*j)%this.cap;
                this.readings++;
                chainCounter++;
            }
        }
        return i;
    }

    public void insert(String key)
    {
        if(this.probFlag.equals("-q"))
        {
            int currentDistance = findPosQuadraticProbing(key);
            this.table[currentDistance] = key;
        }
        else
        {
            int currentDistance = findPosLinearProbing(key);
            this.table[currentDistance] = key;
        }
    }

    public void search(String key)
    {
        if(this.probFlag.equals("-q"))
        {
            findPosQuadraticProbing(key);
        }
        else
        {
            findPosLinearProbing(key);
        }
    }

    public String hashAnalysis()
    {
        StringBuilder output = new StringBuilder();
        double loadFact = this.numberOfRecords/this.cap;
        double averageNumberOfReads = this.readings/this.numberOfRecords;
        double hashEff = loadFact/averageNumberOfReads;
        output.append("Average Number of Reads per Record: "+ averageNumberOfReads + "\nLoadFactor: "+ loadFact+
                        "\nHash Efficiency: "+hashEff+"\nLongest Chain Size: "+this.mChain);
        return output.toString(); 
    }

    public boolean isPrime(int num)
    {
        if(num<=1)
        {
            return false;
        }
        for(int j=2;j<num;j++)
        {
            if(num % j == 0)
            {
                return false;
            }
        }
        return true;
    }

    public int nextPrime(int num)
    {
        while(!isPrime(num))
        {
            num++;
        }
        return num;
    }

    public void resetReads()
    {
        this.readings = 0;
        this.mChain = 0;
    }
}
import java.util.*;
import java.io.*;

public class Utility
{
    private String inFile = new String();
    private String outFile = new String();
    private HashTable hTable = null;

    public Utility(String flag, String inFile,String outFile)
    {
        this.inFile = inFile;
        this.outFile = outFile;

        try
        {
            BufferedReader inRowRead = new BufferedReader(new FileReader(this.inFile+".txt"));
            int l = 0;
            while(inRowRead.readLine() != null)
            {
                l++;
            }
            this.hTable = new HashTable(l,flag);
            inRowRead.close();
        }catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    public void readData()
    {
        try 
        {
            Scanner inScanner = new Scanner(new File(this.inFile+".txt"));
            while(inScanner.hasNextLine())
            {
                String sucString  = inScanner.nextLine();
                this.hTable.insert(sucString);
            }
            inScanner.close();
        }catch(IOException e)
        {
            e.printStackTrace();
        }
    }

    public void searchData()
    {
        try
        {
            this.hTable.resetReads();
            Scanner inScanner = new Scanner(new File(this.inFile+".txt"));
            while(inScanner.hasNextLine())
            {
                String sucString  = inScanner.nextLine();
                this.hTable.insert(sucString);
            }
            inScanner.close();
            writeToFile(this.hTable.hashAnalysis(),this.outFile);
        }catch(IOException e)
        {
            e.printStackTrace();
        }
    }

    public void writeToFile(String data,String outFile)
    {
        try
        {
            FileWriter writer = new FileWriter(outFile+".txt",true);
            writer.write(data+"\r\n");
            writer.close();
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }

    public HashTable getHashTable()
    {
        return this.hTable;
    }
}
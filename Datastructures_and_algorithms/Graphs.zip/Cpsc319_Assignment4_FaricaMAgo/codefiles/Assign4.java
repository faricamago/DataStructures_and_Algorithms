
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;


public class Assign4 {
	Matrix2D adjacencyMatrix;
	Matrix2D weightedAdjacencyMatrix;
    Matrix2D queryList;
    Matrix2D weightedQueryList;
    boolean pathFound;

	public static void main(String[] args) {
		if(args.length != 7) {
    		System.err.println("Insufficient number of arguments!");
    		System.exit(0);
    	}
		if(!(args[0].contains(".txt")) || !(args[1].contains(".txt")) ||
				!(args[2].contains(".txt")) || !(args[3].contains(".txt")) ||
				!(args[4].contains(".txt")) || !(args[5].contains(".txt")) ||
				!(args[6].contains(".txt"))
				) {
			System.err.println("Error: Filenames must be in the format [filename].txt");
			System.exit(0);
		}
    	Assign4 test = new Assign4();
        String input_file = args[0];
        String query_file = args[1];
        String output1_file = args[2];
        String output2_file = args[3];
        String d_input_file= args[4];
        String d_query_file= args[5];
        String output3_file= args[6];
        
        
        
        DiGraph di = null;
        DiGraph wDi = null;
        try {
        	test.clearFile(output1_file);
			test.clearFile(output2_file);
			test.clearFile(output3_file);
		} catch (IOException e1) {
			e1.printStackTrace();
		}

        PrintStream printStream = null;
        try {
            test.adjacencyMatrix = read2DMatrix(input_file);
            int V = test.adjacencyMatrix.getNumberOfRows();
            di = new DiGraph(V);
            for(int r = 0; r < V; r++) {
            	for(int c = 0; c < V; c++) {
            		if(test.adjacencyMatrix.getValue(r, c) == 1)
            			di.addEdge(di.adjacent[r], di.adjacent[c]);
            	}
            }
            test.queryList = read2DMatrix(query_file);
            for(int i = 0; i < test.queryList.getNumberOfRows(); i++){
                int start_node = test.queryList.getValue(i, 0);
                int end_node = test.queryList.getValue(i, 1);   
                printStream = new PrintStream(System.out);
                System.setOut(new PrintStream(new FileOutputStream(output1_file,true)));
                test.printDFS(di.adjacent,start_node, end_node);
                System.setOut(printStream);
                System.setOut(new PrintStream(new FileOutputStream(output2_file,true)));
                test.printBFS(di.adjacent, start_node, end_node);
                System.setOut(printStream);
            }

            test.weightedAdjacencyMatrix = read2DMatrix(d_input_file);
            int weightedV = test.weightedAdjacencyMatrix.getNumberOfRows();
            wDi = new DiGraph(weightedV);
            for(int r = 0; r < weightedV; r++) {
            	for(int c = 0; c < weightedV; c++) {
            		int weight = test.weightedAdjacencyMatrix.getValue(r, c);
            		if(weight != 0)
            			wDi.addWeightedEdge(wDi.weightedAdj[r], wDi.weightedAdj[c], weight);
            	}
            }
            test.weightedQueryList = read2DMatrix(d_query_file);
            for(int j = 0; j < test.weightedQueryList.getNumberOfRows(); j++) {
            	int begin = test.weightedQueryList.getValue(j, 0);
            	int ending = test.weightedQueryList.getValue(j, 1);
            	System.setOut(new PrintStream(new FileOutputStream(output3_file,true)));
            	test.dijkstra(test.weightedAdjacencyMatrix, begin, ending);
            	System.setOut(printStream);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //Converts String to integer array
    public static int[] StringtoIntArr(String string) {
        // Replaces new-line by "" and splits each spaced integer to String
        String[] stringLine = string.replace("\n", "").replace("\r", "")
                .split("\t");
        // Creates the integer array
        int[] intArray = new int[stringLine.length];
        for (int k = 0; k < intArray.length; k++) {
            // Parses the integer for each string
            intArray[k] = Integer.parseInt(stringLine[k]);
        }
        return intArray;
    }

    //Reads from input file and returns 2D Matrix
    public static Matrix2D read2DMatrix(String input) throws IOException {
        BufferedReader bufferReader = null;
        Matrix2D matrix = new Matrix2D();
        try {
            bufferReader = new BufferedReader(new FileReader(input));
            String string = bufferReader.readLine();
            int[] arr = StringtoIntArr(string);
            int c = arr.length;
            int r = 0;
            while (string != null) {
                arr = StringtoIntArr(string);
                for (int i = 0; i < c; i++)
                    matrix.addValue(r, i, arr[i]);
                string = bufferReader.readLine();
                r++;
            }
        } catch (IOException err) {
            System.err.println("An I/O exception occurred.");
        } finally {
            if (bufferReader != null) {
                bufferReader.close();
            } else
                System.err.println("BufferedReader could not be opened.");
        }
        return matrix;
    }
    
    public void clearFile(String filename) throws IOException {
    	File file = new File(filename);
    	if(!file.exists())
    		file.createNewFile();
    	else
    		file.delete();
    }
    
    public void printDFS(Vertex[] adjacent, int begin, int ending) {
    	String str = "";
    	pathFound = false;
    	int i = 0;
    	while(i < adjacent.length) {
    		adjacent[i].visited = false;
    		i++;
    	}
    	try {
			DFS(adjacent,adjacent[begin],adjacent[ending],str);
		} catch (NullPointerException|IOException e) {
			e.printStackTrace();
		}
    	if(!pathFound) {
    		System.out.print(begin + "   , -1  , " + ending);
    	}
    	System.out.println();    	
    }
    
    public void DFS(Vertex[] adjacent, Vertex source, Vertex sink, String str) throws IOException, NullPointerException {
    	if(source.visited) {
    		return;
    	}
    	else {
    		source.visited = true;
    		String temporary = Integer.toString(source.key);
    		while(temporary.length() < 3)
    			temporary += " ";
    		if(source.key != sink.key)
    			temporary += " , ";
    		str += temporary;
    		int i = 0;
    		if(source.key == sink.key) {
    			pathFound = true;
	    		while(i < adjacent.length) {
	    			adjacent[i].visited = true;
	    			i++;
	    		}
	    		System.out.print(str);
    		}
    		else if(source.outgoingEdge[0] != null) {
    			while(i < source.outgoingEdge.length) {
    				DFS(adjacent, source.outgoingEdge[i].next, sink, str);
    				i++;
    			}
    		}
    	}
    }
    
    public void printBFS(Vertex[] adjacent, int begin, int ending) throws IOException, NullPointerException {
    	if(adjacent == null)
    		return;
    	Queue q = new Queue();
    	Vertex curr = null;
    	int i = 0;
    	while(i < adjacent.length) {
    		adjacent[i].visited = false;
    		i++;
    	}
    	q.enqueue(adjacent[begin]);
    	String str = "";
    	boolean found = false;
    	while(!q.isEmpty()) {
    		curr = q.dequeue();
    		String temporary = Integer.toString(curr.key);
    		while(temporary.length() < 3)
    			temporary += " ";
    		if(curr.key != adjacent[ending].key)
    			temporary += " , ";
    		str += temporary;
    		i = 0;
    		if(curr.outgoingEdge[i] != null) {
    			while(i < curr.outgoingEdge.length) {
    				if(!curr.outgoingEdge[i].next.visited) {
    					curr.outgoingEdge[i].next.visited = true;
    					q.enqueue(curr.outgoingEdge[i].next);
    				}
    				if(curr.outgoingEdge[i].next.key == adjacent[ending].key) {
    					int j = 0;
    					while(j < adjacent.length) {
    						adjacent[j].visited = true;
    						j++;
    					}
    					found = true;
    				}
    				i++;
    			}
    		}
    	}
    	if(!found)
    		str = begin + "   , " + "-1" + "  , " + ending;
    	System.out.println(str);
    }
    
    public void dijkstra(Matrix2D matrix, int source, int destination) {
    	int arr = matrix.getNumberOfRows();
    	int[] dist= new int[arr];
    	boolean shortestPath[] = new boolean[arr];
    	for(int i = 0; i < arr; i++){
    		dist[i] = Integer.MAX_VALUE;
    		shortestPath[i] = false;
    	}
    	dist[source] = 0;
    	System.out.print(source + " , ");
    	for(int index = 0; index < arr; index++) {
    		int u = minDist(dist,shortestPath);
    		shortestPath[u] = true;
    		for(int k = 0; k < arr; k++) {
    			if(!shortestPath[k] && matrix.getValue(u,k) != 0 && dist[u] != Integer.MAX_VALUE && (dist[u] + matrix.getValue(u,k) < dist[k])) {
    				dist[k] = dist[u] + matrix.getValue(u,k);
    				System.out.print(k + " , ");
    				if(k == destination)
    					break;
    			}
    			
    		}
    	}
    	System.out.println(destination);
    }

    public int minDist(int[] dist, boolean[] shortestPath) {
    	int minimum = Integer.MAX_VALUE;
    	int i = -1;
    	for(int k = 0; k < dist.length; k++) {
    		if(!shortestPath[k] && dist[k] <= minimum) {
    			minimum = dist[k];
    			i = k;
    		}
    	}
    	return i;
    }
}
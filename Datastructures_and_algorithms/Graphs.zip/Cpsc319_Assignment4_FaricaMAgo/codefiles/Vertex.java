
public class Vertex
{
	final int key;	
	int dist = Integer.MAX_VALUE;	
	Edge[] outgoingEdge;	
	WeightedEdge[] outgoingWeightedEdge;
	boolean visited;
	
	Vertex(int k)
	{
		this.key = k;
		outgoingEdge = new Edge[1];
		outgoingWeightedEdge = new WeightedEdge[1];
		visited = false;
	}
	
	public void setDistance(int d)
	{
		dist = d;
	}
}

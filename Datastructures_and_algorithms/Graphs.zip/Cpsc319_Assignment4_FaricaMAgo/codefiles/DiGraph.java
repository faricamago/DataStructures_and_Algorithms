
public class DiGraph
{
	int Ver;
	Vertex [] adjacent;
	Vertex [] weightedAdj;
	
	DiGraph(int numberOfVertices)
	{
		Ver = numberOfVertices;
		adjacent = new Vertex[Ver];
		weightedAdj = new Vertex[Ver];	
		for(int j = 0; j < Ver; j++)
		{
			adjacent[j] = new Vertex(j);
			weightedAdj[j] = new Vertex(j);
		}
	}
	
	public void addEdge(Vertex s, Vertex d) // s= source, d= destination
	{
		if(s.outgoingEdge[0] == null)
			s.outgoingEdge[0] = new Edge(s,d);
		else
		{
			int length = s.outgoingEdge.length;
			Edge[] temporary = new Edge[length + 1];
			int i = 0;
			while(i < length)
			{
				temporary[i] = s.outgoingEdge[i];
				i++;
			}
			temporary[i] = new Edge(s,d);
			s.outgoingEdge = temporary;
		}
	}
	
	public void addWeightedEdge(Vertex s, Vertex d, int weight) // s= source, d= destination
	{
		if(s.outgoingWeightedEdge[0] == null)
			s.outgoingWeightedEdge[0] = new WeightedEdge(s, d, weight);
		else
		{
			int length = s.outgoingWeightedEdge.length;
			WeightedEdge[] temporary = new WeightedEdge[length + 1];
			int i = 0;
			while(i < length)
			{
				temporary[i] = s.outgoingWeightedEdge[i];
				i++;
			}
			temporary[i] = new WeightedEdge(s, d, weight);
			s.outgoingWeightedEdge = temporary;
		}
	}
}

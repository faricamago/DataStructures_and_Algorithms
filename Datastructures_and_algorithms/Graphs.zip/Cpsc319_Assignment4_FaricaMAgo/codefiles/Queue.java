
public class Queue
{
	LList<Vertex> list;
	LList<Vertex> headVertex;
	LList<Vertex> tailVertex;
	
	Queue()
	{
		list = new LList<Vertex>();
		headVertex = tailVertex = null;
	}
	
	public void enqueue(Vertex d) {
		if(tailVertex == null)
			headVertex = tailVertex = list;
		else {
			LList<Vertex> temporary = new LList<Vertex>();
			tailVertex.next = temporary;
			tailVertex = temporary;
		}
		tailVertex.add(d);
		d.visited = true;
	}
	
	public Vertex dequeue() {
		Vertex temporary;
		if(headVertex == null)
			return null;
		else {
			temporary = headVertex.data;
			if(headVertex == tailVertex) {
				headVertex = tailVertex = null;
				list = new LList<Vertex>();
			}
			else
				headVertex = headVertex.next;
		}
		return temporary;
	}
	
	public boolean isEmpty() {
		if(list.data == null)
			return true;
		return false;
	}
}

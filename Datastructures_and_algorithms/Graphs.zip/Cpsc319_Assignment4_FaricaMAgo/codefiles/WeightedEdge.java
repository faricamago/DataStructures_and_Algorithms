
public class WeightedEdge extends Edge {
	
	int w;
	WeightedEdge(Vertex s, Vertex d, int weight) {
		super(s, d);
		this.w = weight;
	}

}

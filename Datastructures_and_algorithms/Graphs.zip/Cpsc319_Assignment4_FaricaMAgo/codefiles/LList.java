
public class LList <T>
{
	T data;
	LList<T> next;
	
	LList(T d)
	{
		this.data = d;
		next = null;
	}
	
	LList()
	{
		this(null);
	}
	
	public void add(T d)
	{
		if(this.data == null)
			this.data = d;
	}
}


public class Edge
{
	Vertex previous;	
	Vertex next;	
	
	Edge(Vertex source, Vertex dest)
	{
		previous = source;
		next = dest;
	}
	
	public Vertex getNeighbour(int i)
	{
		if(previous.key == i)
			return next;
		return previous;
	}
}

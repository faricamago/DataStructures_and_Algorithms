
class Matrix2D {

    private int[][] matrixArray;

    Matrix2D()
    {

        setMatArr(new int[1][1]);
    }

    Matrix2D(int row, int column)
    {
        setMatArr(new int[row][column]);
    }

    public int[][] getMatArr()
    {
        return matrixArray;
    }

    public void setMatArr(int[][] matrixArr)
    {
        this.matrixArray = matrixArr;
    }

    void addValue(int a, int b, int v)
    {
        ensureCapacity(a, b);
        matrixArray[a][b] = v;
    }

    public void ensureCapacity(int a, int b)
    {
        if (a >= matrixArray.length) {
            int[][] temporary = matrixArray;
            matrixArray = new int[a + 1][];
            System.arraycopy(temporary, 0, matrixArray, 0, temporary.length);
            for (int j = a; j < a + 1; j++)
            {
                matrixArray[j] = new int[b];
            }
        }

        if (b >= matrixArray[a].length)
        {
            int[] temporary = matrixArray[a];
            matrixArray[a] = new int[b + 1];
            System.arraycopy(temporary, 0, matrixArray[a], 0, temporary.length);
        }

    }

    int getValue(int a, int b)
    {
        validateIndex(a, b);
        return matrixArray[a][b];
    }
    
    int[] getRow(int a)
    {
        validateIndex(a, 0);
        return matrixArray[a];
    }

    int getNumberOfRows()
    {
        return matrixArray.length;
    }

    void print()
    {
        for (int i = 0; i < matrixArray.length; i++)
        {
            for (int j = 0; j < matrixArray[i].length; j++)
                System.out.print(matrixArray[i][j] + " ");
            System.out.println();
        }
    }

    private void validateIndex(int a, int b)
    {
        int V = matrixArray.length;
        if (a < 0 || a >= V)
            throw new IllegalArgumentException("Error: Index " + a
                    + " is not between 0 and " + (V - 1));
        if (b < 0 || b >= V)
            throw new IllegalArgumentException("Error: Index " + b
                    + " is not between 0 and " + (V - 1));
    }
}
I have attempted the bonus part.

To run the program:
- Download the zip folder. Download the "codefiles" folder on your PC.
- Open command prompt.
- open the directory "codefiles" in command prompt.
- Complie .java files using "javac *.java"
- run the programs files using the command "java Assign4 input.txt query.txt output1.txt output2.txt inputDijkstra1.txt queryDijkstra1.txt output3.txt"
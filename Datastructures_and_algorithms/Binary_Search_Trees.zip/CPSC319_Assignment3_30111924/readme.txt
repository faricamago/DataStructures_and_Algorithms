How to compile amd run the program:
1) download the folder "Assignment3" on the desktop.
2) open this directory in the command prompt.
3) complie the files using the command "javac *.java"
4) run the file using the command "java Assign3 input output1 output2"

I have not done the bonus part.
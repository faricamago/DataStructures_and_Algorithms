
import java.io.*;
import java.util.Scanner;

public class Utility {

    private String inputFile = new String();
    private String outputFileOne = new String();
    private String outputFileTwo = new String();
    private BinaryTree binaryTree = new BinaryTree();

    public Utility(String inputFile,String outputFileOne, String outputFileTwo)
    {
      this.inputFile = inputFile;
      this.outputFileOne = outputFileOne;
      this.outputFileTwo = outputFileTwo;
    }

   public void readData()
   {
     try {
       String line;
       File file = new File(this.inputFile + ".txt");
       Scanner scanner = new Scanner(file).useDelimiter("\\n");

       while(scanner.hasNext())
       {
         line = scanner.nextLine();
         if(line.substring(0,1).equals("I"))
         {
            binaryTree.insert(line.substring(1));
         }
         else if(line.substring(0,1).equals("D"))
         {
            binaryTree.delete(line.substring(1));
         }
       }
       scanner.close();
      
     }catch(IOException e)
     {  
       e.printStackTrace();
     }
   }
  
  public void writeToFile(String data, String outputFile)
  {

    try {
        FileWriter writer = new FileWriter(outputFile + ".txt", true);
        writer.write(data + "\r\n");
        writer.close();
   }catch (IOException e)
   {
       e.printStackTrace();
   }
  }

  public void inOrder(Node currentNode)
  {
      if(currentNode != null)
      {
          inOrder(currentNode.leftChild);
          writeToFile(currentNode.toString(), this.outputFileOne);
          System.out.println(currentNode.toString());
          inOrder(currentNode.rightChild);
      }
  }
  
   public void breadthFirst(Node root)
   {
     Node currentNode = root;
     Queue queue = new Queue(binaryTree.getSize());
     if (currentNode != null)
     {
        queue.enqueue(currentNode);
        while (!queue.isEmpty())
        {
            currentNode = queue.dequeue();
            writeToFile(currentNode.toString(), this.outputFileTwo);
            System.out.println(currentNode.toString());
            if (currentNode.leftChild !=null)
                queue.enqueue(currentNode.leftChild);
            if (currentNode.rightChild !=null)
                queue.enqueue(currentNode.rightChild);
        }
      }
    }

    public BinaryTree getBinaryTree()
    {
        return this.binaryTree;
    }
}

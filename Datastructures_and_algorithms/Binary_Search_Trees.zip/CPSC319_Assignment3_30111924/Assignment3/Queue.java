
public class Queue
{
    private Node[] array;
    private int front;
    private int rear;
    private int capacityOfQueue;
    private int currentSize;

    public Queue(int size)
    {
        array = new Node[size];
        capacityOfQueue = size;
        rear = -1;
        front= 0;
        currentSize = 0;
    }

    public Node dequeue()
    {
        if(isEmpty())
        {
            System.out.println("The program is terminated because of Underflolw");
            System.exit(1);
        }
        Node a = array[front];
        front = (front+1)%capacityOfQueue;
        currentSize--;
        return a;
    }

    public void enqueue(Node x)
    {
        if(isFull())
        {
            System.out.println("The program is terminated because of Overflow");
            System.exit(1);
        }
        rear = (rear+1) % capacityOfQueue;
        array[rear] = x;
        currentSize++;
        }

        public int size()
        {
            return currentSize;
        }

        public boolean isEmpty()
        {
            return (size()==0);
        }

        public boolean isFull()
        {
            return (size()==capacityOfQueue);
        }
}

public class Node
{
    String data;
    Node parentNode;
    Node leftChild;
    Node rightChild;

    public Node(String stuData)
    {
        this.data = stuData;
        this.parentNode = null;
        this.leftChild = null;
        this.rightChild = null;
    }

    public String toString()
    {
        return data;
    }
}
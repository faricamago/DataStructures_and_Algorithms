
public class Assign3
{
    public static void main(String[] args)
    {
      if((args.length)!=3)
      {
        System.out.println("The number of arguments specified is wrong!");
      }
      Utility myTesting = new Utility(args[0], args[1], args[2]);
      myTesting.readData();
      myTesting.inOrder(myTesting.getBinaryTree().getRoot());
      System.out.println();
      myTesting.breadthFirst(myTesting.getBinaryTree().getRoot());   
     }
}

public class BinaryTree
{
    private Node root;
    private int theSize;
    
    public BinaryTree()
    {
        this.root = null;
    }

    public void insert(String stuData)
    {
        Node newNode = new Node(stuData);
        Node currentNode = root;
        Node parentNode = null;

        while(currentNode != null)
        {
            parentNode = currentNode;
            if(stuData.substring(7,32).toLowerCase().compareTo(currentNode.data.substring(7,32).toLowerCase())>0)
            {
                currentNode = currentNode.rightChild;
            }
            else
            {
                currentNode = currentNode.leftChild;
            }
        }
        if(root == null)
        {
            root = newNode;
        }
        else if(stuData.substring(7,32).toLowerCase().compareTo(parentNode.data.substring(7,32).toLowerCase())>0)
        {
            parentNode.rightChild = newNode;
            newNode.parentNode = parentNode;
        }
        else
        {
            parentNode.leftChild = newNode;
            newNode.parentNode = parentNode;
        }
        this.theSize++;
    }

    public void delete(String stuData)
    {
        this.root = deleteData(this.root,stuData);
        this.theSize--;
    }

    public Node deleteData(Node root, String stuData)
    {
        if(root == null)
        {
            return root;
        }
        if(stuData.substring(7,32).toLowerCase().compareTo(root.data.substring(7,32).toLowerCase())<0)
        {
            root.leftChild = deleteData(root.leftChild,stuData);
        }
        else if(stuData.substring(7,32).toLowerCase().compareTo(root.data.substring(7,32).toLowerCase())>0)
        {
            root.rightChild = deleteData(root.rightChild,stuData);
        }
        else
        {
            if(root.leftChild == null)
            {
                return root.rightChild;
            }
            else if(root.rightChild == null)
            {
                return root.leftChild;
            }
            root.data = minValue(root.rightChild);
            root.rightChild = deleteData(root.rightChild,root.data);
        }
        return root;
    }
    public String minValue(Node root)
    {
        String minimumValue = root.data;
        while(root.leftChild != null)
        {
            minimumValue = root.leftChild.data;
            root = root.leftChild;
        }
        return minimumValue;
    }

    public Node getRoot()
    {
        return this.root;
    }

    public int getSize()
    {
        return this.theSize;
    }
}

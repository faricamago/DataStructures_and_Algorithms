/*
NAME: FARICA MAGO
COURSE: CPSC 319
TUTORIAL: T01
ASSIGNMENT NUMBER: 1
TA NAME: MD SHOPON
*/

import java.io.FileWriter;
import java.util.Random;

public class Assign1 
{
    public static void selectionSort(int[] array)
    {
        for (int i = 0; i < array.length-1; i++)
        {
            // Find the least element in right subarray
            int min_or_max = i;           
                for (int j = i + 1; j < array.length; j++)
                    if (array[j] < array[min_or_max])
                    min_or_max = j;
            
            
            // Swap items
            int temp = array[min_or_max];
            array[min_or_max] = array[i];
            array[i] = temp;
        }
    }
    public static void selectionSortDesc(int[] array)
    {
        for (int i = 0; i < array.length-1; i++)
        {
            // Find the least element in right subarray
            int min_or_max = i;           
                for (int j = i + 1; j < array.length; j++)
                    if (array[j] > array[min_or_max])
                    min_or_max = j;
            
            
            // Swap items
            int temp = array[min_or_max];
            array[min_or_max] = array[i];
            array[i] = temp;
        }
    }

    public static void insertionSort(int[] array)
    {
        
            for (int i = 1, j; i < array.length; i++)
            {
                int temp = array[i];
                for (j = i; j > 0 && temp < array[j-1]; j--)
                    array[j] = array[j-1];
                array[j] = temp;
            }
    }

    public static void mergeSort(int[] array)
    {

        
            if(array == null)
            {
                return;
            }
 
            if(array.length > 1)
            {
                int mid = array.length / 2;
 
                // Split left part
                int[] left = new int[mid];
                for(int i = 0; i < mid; i++)
                {
                    left[i] = array[i];
                }
             
                // Split right part
                int[] right = new int[array.length - mid];
                for(int i = mid; i < array.length; i++)
                {
                    right[i - mid] = array[i];
                }
                mergeSort(left);
                mergeSort(right);
 
                int i = 0;
                int j = 0;
                int k = 0;
 
                // Merge left and right arrays
                while(i < left.length && j < right.length)
                {
                    if(left[i] < right[j])
                    {
                        array[k] = left[i];
                        i++;
                    }
                    else
                    {
                        array[k] = right[j];
                        j++;
                    }
                    k++;
                }
                // Collect remaining elements
                while(i < left.length)
                {
                    array[k] = left[i];
                    i++;
                    k++;
                }
                while(j < right.length)
                {
                    array[k] = right[j];
                    j++;
                    k++;
                }
            }        
    }
    static void swap(int[] arr, int i, int j)
    {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    static void quicksort(int[] array, int first, int last)
    {
        int lower = first + 1, upper = last;
        // Use the middle array element as the bound (pivot) and 
        // move it out of the way into the first array element 
        swap(array, first, (first + last)/2);
        int bound = array[first];
        // Partition the array 
        while (lower <= upper)
        {
            while (array[lower] < bound)
                lower++;
            while (array[upper] > bound)
                upper--;
            if (lower < upper)
                swap(array, lower++, upper--);
            else
                lower++;
        }
        // Move the pivot into its proper position in the array 
        swap(array, upper, first);
        // Recursively sort the lower and upper subarrays 
        if (first < upper-1)
            quicksort(array,first, upper-1);
        if ((upper+1) < last)
            quicksort(array,upper+1, last);
    }

    public static void quickSort(String what_order,int[] array)
    {
        // An array of size 1 is already sorted 
        if (array.length < 2)
        return;
        // Find the largest element and put it at the end of the array 
        int max = 0;
        for (int i = 1; i < array.length; i++)
        {
                if (array[i] > array[max])
                max = i;
            
        }
        swap(array,array.length-1, max);
        // Call the main quicksort method 
        quicksort(array,0, array.length-1);
    }

    
    public static void main(String[] args)throws Exception
    {

        //checking if the input is correct
        if(args[0].equalsIgnoreCase("ascending") || args[0].equalsIgnoreCase("descending") ||args[0].equalsIgnoreCase("random"))
        {
            int firstArg;
            if (args.length > 0)
            {
                try
                {
                    firstArg = Integer.parseInt(args[1]);
                } catch (NumberFormatException e)
                {
                    System.err.println("Argument" + args[1] + " must be an integer.");
                    System.exit(1);
                }
            }
            if(args[2].equalsIgnoreCase("selection") || args[2].equalsIgnoreCase("insertion") ||args[2].equalsIgnoreCase("merge") ||args[2].equalsIgnoreCase("quick"))
            {
                ;
            }
            else
            {
                throw new Exception("Wrong input for algorithm\n");
            }
        }
        else
        {
            throw new Exception("Wrong input for order\n");
        }

        //creating a array input
        int size_of_array = Integer.parseInt(args[1]); 
		int[] random_array = new int[size_of_array]; 
		Random rnd = new Random(); 
		for(int i=0;i<size_of_array;i++)
        {
			random_array[i] = rnd.nextInt(1000);
		}

        if(args[0].equalsIgnoreCase("ascending"))
        {
            selectionSort(random_array);
        }
        else if(args[0].equalsIgnoreCase("descending"))
        {
            selectionSortDesc(random_array);
        }
        else
        {
            ;
        }


        if(args[2].equalsIgnoreCase("selection"))
        {
            long startTime = System.nanoTime();
            selectionSort(random_array);
            long elapsedTime = System.nanoTime() - (startTime);
            System.out.println("Timetaken to sort the array is: "+elapsedTime);
        }
        else if(args[2].equalsIgnoreCase("insertion"))
        {
            long startTime = System.nanoTime();
            insertionSort(random_array);
            long elapsedTime = System.nanoTime() - (startTime);
            System.out.println("Timetaken to sort the array is: "+elapsedTime);
        } 
        else if(args[2].equalsIgnoreCase("merge"))
        {
                long startTime = System.nanoTime();
                mergeSort(random_array);
                long elapsedTime = System.nanoTime() - (startTime);
                System.out.println("Timetaken to sort the array is: "+elapsedTime);
        }
        else
        {
                long startTime = System.nanoTime();
                quickSort(args[0],random_array);
                long elapsedTime = System.nanoTime() - (startTime);
                System.out.println("Timetaken to sort the array is: "+elapsedTime);
        }
        String filePath = "C:/Users/HP/Desktop/winter2022/CPSC319"+args[3]+".txt";  
        FileWriter writer = new FileWriter(filePath);
        for(int i=0;i<size_of_array;i++)
        {
            writer.write(random_array[i]+"\n");
        }
        writer.close();

    }    
}
